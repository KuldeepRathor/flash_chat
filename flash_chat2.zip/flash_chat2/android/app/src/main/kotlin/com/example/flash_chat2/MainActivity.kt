package com.example.flash_chat2

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
